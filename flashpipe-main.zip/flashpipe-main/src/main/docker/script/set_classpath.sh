echo "[INFO] Setting WORKING_CLASSPATH environment variable"
#FLASHPIPE_VERSION
export WORKING_CLASSPATH=/usr/share/maven/ref/repository/io/github/engswee/flashpipe/1.0.2/flashpipe-1.0.2.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/org/codehaus/groovy/groovy-all/2.4.21/groovy-all-2.4.21.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/org/apache/httpcomponents/core5/httpcore5/5.0.4/httpcore5-5.0.4.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/org/apache/httpcomponents/client5/httpclient5/5.0.4/httpclient5-5.0.4.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/commons-codec/commons-codec/1.15/commons-codec-1.15.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/org/slf4j/slf4j-api/1.7.25/slf4j-api-1.7.25.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/org/apache/logging/log4j/log4j-slf4j-impl/2.14.1/log4j-slf4j-impl-2.14.1.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/org/apache/logging/log4j/log4j-api/2.14.1/log4j-api-2.14.1.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/org/apache/logging/log4j/log4j-core/2.14.1/log4j-core-2.14.1.jar
export WORKING_CLASSPATH=$WORKING_CLASSPATH:/usr/share/maven/ref/repository/org/zeroturnaround/zt-zip/1.14/zt-zip-1.14.jar