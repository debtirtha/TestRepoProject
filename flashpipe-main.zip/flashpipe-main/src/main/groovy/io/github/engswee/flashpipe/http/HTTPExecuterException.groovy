package io.github.engswee.flashpipe.http

class HTTPExecuterException extends Exception {

    HTTPExecuterException(String message) {
        super(message)
    }
}